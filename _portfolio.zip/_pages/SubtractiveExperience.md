---
title: "Subtractive Projects"
layout: single
permalink: /subtractive/
author_profile: true
classes: wide
---

Projects focused on subtractive manufacturing and fabrication workflows.

## Icon Frames

This page is a placeholder for the Icon Frames project. The full write-up will include machining strategy, fixture setup, tooling selections, tolerance checks, and finished part photos once documentation is finalized.
