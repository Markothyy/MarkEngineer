---
title: "VADL Projects"
layout: single
permalink: /vadl/
author_profile: true
classes: wide
---

Projects completed through the Vanderbilt Aerospace Design Lab.

## Carbon Fiber Airframe Cutting Jig

![Carbon Fiber Airframe Cutting Jig](/assets/img/1767337100637.jpg)

### Features

* **Massive Print Area: 1140 x 1200 x 1100 mm.** With a build envelop just shy of 4 feet in all dimensions, the LF3DP is capable of printing furniture and other large objects.
* **High Volumetric Output Extruder: 1 kg/hr - 450 C.** This printer come standard with a MDPH2 extruder by Massive Dimension, which can extrude at a rate of 1 kg/hr. Unlike typical filament extruders, the MDPH2 uses a screw to convey and liquify plastic pellets before the molten material is pushed out of a large nozzle (1 to 5 mm extrusion diameter). Please note: This printer can also be configured for other high flow rate extruders, such as the Typhoon and Pulsar by Dyze Design.
* **Affordable Pellet Feedstock** Pellets are the cheapest form of feedstock for any plastic-based manufacturing process. Save 50-75% of material costs by using pellets instead of spools of filament. Concentrated colorant can be added to the virgin material to achieve any color in the rainbow without requiring large amounts of storage. Recyled material can also be used for sustainable material printing.

### CAD Model
<iframe src="https://vanderbilt643.autodesk360.com/shares/public/SH90d2dQT28d5b602811e513816e89740228?mode=embed" width="640" height="480" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"  frameborder="0"></iframe>

### Photo Gallery

![Gallery Image 1](/assets/img/Slide-3.png)
![Gallery Image 2](/assets/img/Slide-2.png)
![Gallery Image 3](/assets/img/Slide-4.png)

## Tail Section Manufacturing Jig

The tail section manufacturing jig page is currently a placeholder. This section will be expanded with full process documentation, fixture design rationale, setup photos, and final manufacturing validation results once the latest build data is finalized.
